from django.apps import AppConfig


class LinkedinOptimizerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'linkedin_optimizer'
